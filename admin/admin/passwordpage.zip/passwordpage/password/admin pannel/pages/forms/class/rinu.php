<?php

$xyz=new PDO('mysql:host=localhost;dbname=matrim','root','');

?>